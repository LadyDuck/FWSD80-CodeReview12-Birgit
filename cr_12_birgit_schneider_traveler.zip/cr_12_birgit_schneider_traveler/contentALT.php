<section <?php post_class();?>>
          
       <div class="card">
        
        <div class ="image">
          <img src="<?php echo the_post_thumbnail_url($post_id, 'thumbnail')?>" class="card-img-top" alt="...">
        </div>
          <div class="card-body">
            <h5 class="card-title"><a href="<?php the_permalink();?>"><?php the_title()?></a></h5>
            <p><?php the_time('d.m.Y');?> by <?php the_author();?></p>
            <p class="card-text"><?php the_content() ?></p>
          </div>
        </div>
        
        
    </section>