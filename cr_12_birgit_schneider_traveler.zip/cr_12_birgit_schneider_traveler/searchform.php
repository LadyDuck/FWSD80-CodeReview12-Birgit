<form method="get" action="<?php bloginfo('url');?>/" class ="site-search form-inline my-2 my-lg-0">
    
        <input class="form-control mr-sm-2" type="text" placeholder="Search" type="search" name = "s">
        
        <button type="submit" class="btn btn-outline-primary my-2 my-sm-0">Search</button>

    <!--    <input type="submit" value = "Search" />-->
        
</form>


