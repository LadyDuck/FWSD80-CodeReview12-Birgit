<?php get_header(); ?>
    
<main class = "site-main">
    
    <h2>Results for your search for: <?php echo $s ;?></h2>

    <div class = "row">
        
    <!--    <article class = "site-content"> -->

            <div class ="col-9">


                 <div class = "loop">

                   <!-- Start Loop --> 

                        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                            <?php get_template_part('template_parts/content'); ?>

                        <?php endwhile; else : ?>

                           <?php get_template_part('template_parts/content','error'); ?>

                        <!-- End Loop -->
                        <?php endif; ?>
                     
                        <?php previous_posts_link();?>
                        <?php next_posts_link();?>

                  </div>

            </div>
        
            
            
 
    <!--     </article> -->

            <div class ="col-3">

                <?php get_sidebar(); ?>  

            </div>

        </div>
    
</main> 

<?php get_footer(); ?>

