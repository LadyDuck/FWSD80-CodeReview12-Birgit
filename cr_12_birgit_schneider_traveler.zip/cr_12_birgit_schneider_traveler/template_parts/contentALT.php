    



<div class = "container-fluid">

<div class="card-group mb-4">
  <div class="card mx-1 border ">
    <img src="<?php echo the_post_thumbnail_url($post_id, 'thumbnail')?>" class="card-img-top" alt="USA">
    <div class="card-body">
      <h5 class="card-title"><a href="<?php the_permalink();?>"><?php the_title()?></a></h5></h5>
      <p class="card-text"><?php the_content() ?></p>
      <p class="card-text"><small class="text-muted"><?php the_time('d.m.Y');?> by <?php the_author();?></small></p>
    </div>
  </div>
    
    
 