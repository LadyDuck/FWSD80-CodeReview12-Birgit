
<?php if(is_active_sidebar('sidebar')): ?>
    <aside class ="site-sidebar">

        <?php dynamic_sidebar('sidebar');?>
        
    </aside>

<?php endif; ?>