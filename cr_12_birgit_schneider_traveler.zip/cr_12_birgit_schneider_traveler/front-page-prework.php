<?php get_header(); ?>



  <section class="boxes">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-4">
          <div class="box">
            <i class="fa fa-paper-plane" aria-hidden="true"></i>
            <h3>Lorem Ipsum Dolor</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at. </p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
            <i class="fa fa-comments" aria-hidden="true"></i>
            <h3>Lorem Ipsum Dolor</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
            <i class="fa fa-power-off" aria-hidden="true"></i>
            <h3>Lorem Ipsum Dolor</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
      </div>
    </div>
  </section>


<div class="container-fluid">
    
 <div class = "row">
           
        <!-- Start Loop --> 

                <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
               
                 <?php get_template_part('template_parts/content','page'); ?>

                <?php endwhile; else : ?>

                   <?php get_template_part('template_parts/content','error'); ?>

                <!-- End Loop -->
                <?php endif; ?>
               
                            
 
                <?php 
                
                $args = array(
                        'post_type' =>'post',
                        'posts_per_page' =>4
                );
                
                $loop2 = new WP_Query($args);
                    
                if ( $loop2->have_posts() ) : while ( $loop2->have_posts() ) : $loop2->the_post(); ?>
                    <?php get_template_part('template_parts/content'); ?>
                <?php endwhile; else : ?>
                   <?php get_template_part('template_parts/content','error'); ?>
                <!-- End Loop -->
                <?php endif; wp_reset_postdata()?>
                
                   </div>
            
                </div>
            
        
            

<?php get_footer(); ?>